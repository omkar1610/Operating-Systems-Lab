#include "alt2.h"

using namespace std;


// Declerations
int file_size, block_size, n_blocks;
file_sys file;
vector<FD_t> FD;

int cur_dir;


/////////////////////////////////////////////////////////////////////////////////////////
void init(int a, int b, int c)
{
	::file_size = a;
	::block_size = b;
	::n_blocks = c;

	int i;

	file.sp.file_sys_size = ::file_size;
	file.sp.block_size = ::block_size;
	file.sp.n_blocks = ::n_blocks;
	file.sp.n_inodes = 2 * (::block_size/sizeof(inode));
	file.sp.name = "INODE";
	file.sp.free_block = 3;
	
	file.b_inode.iNode = (inode *)malloc(file.sp.n_inodes * sizeof(inode));
	file.sp.free_inode=(bool*)malloc(file.sp.n_inodes * sizeof(bool));
	for(i=0; i<file.sp.n_inodes; i++)
		file.b_inode.iNode[i].free = true;
	// Populate free_inode list
	bool topush=true;
	
	for(i=0; i<file.sp.n_inodes; i++)
		file.sp.free_inode[i]=true;
	
	file.b = (data_block *)malloc((::n_blocks-3)*sizeof(data_block));
	
	for(i=0; i<(::block_size-3); i++)
	{
		file.b[i].next = i+4;
		file.b[i].data = (char *)malloc(::block_size*1024*sizeof(char));
	}
	
	file.b_inode.iNode[0].free = false;
	file.b_inode.iNode[0].type = false;
	
	file.sp.free_inode[0] = 0;
	//cout<<"\nHere..."<<endl;
	int tp=-1;
	//for(int i=0; i<5; i++)
	//	file.b_inode.iNode[0].dp.push_back(tp);
	file.b_inode.iNode[0].dp.resize(5,tp);
	file.b_inode.iNode[0].sip=file.b_inode.iNode[0].dip=-1;
	cur_dir = 0;
	prev_dir=-1;
}
/////////////////////////////////////////////////////////////////////////////////////////
int getpointertonextentry(int inodeno, int moveby, int* currentdatablockno,int* currentdatablockoffset, int* indirectiontype, int* directoffset, int* sipblockoffset, int* dipblockoffset1, int* dipblockoffset2 )
{

	if(*currentdatablockoffset+moveby<block_size)
	{
		*currentdatablockoffset=*currentdatablockoffset+moveby;
		return (*indirectiontype);
	}
	else if(*currentdatablockno==file.b_inode.iNode[inodeno].last_data_block)
	{
		return -1;
	}
	else if (*indirectiontype==0 && *directoffset<4)
	{
		*directoffset++;
		*currentdatablockno=file.dp[*directoffset];
		*currentdatablockoffset=0;
		return 0;
	}
	else if (*indirectiontype==0 && *directoffset==4)
	{
		*indirectiontype=1;
		*sipblockoffset=0;
		int* ptr=(int*)file.b[file.b_inode.iNode[inodeno].sip-3].data;
		*currentdatablockno=*ptr;
		*currentdatablockoffset=0;
		return (*indirectiontype);
	}
	else if(*indirectiontype==1 && (*sipblockoffset+sizeof(int))<block_size)
	{
		*sipblockoffset+=sizeof(int);
		int* ptr=(int*)((char*)file.b[file.b_inode.iNode[inodeno].sip-3].data+sizeof(int));
		*currentdatablockno=*ptr;
		*currentdatablockoffset=0;
		return (*indirectiontype);
	}
	else if(*indirectiontype==1 && (*sipblockoffset+sizeof(int))>=block_size)
	{
		*indirectiontype=2;
		*dipblockoffset1=0;
		*dipblockoffset2=0;
		int dipblockno=file.b_inode.iNode[inodeno].dip;
		int* tempptr=(int*)((char*)file.b[dipblockno-3].data+*dipblockoffset1);
		int actualsearchinblock=*tempptr;
		int* tempptr2=(int*)((char*)file.b[actualsearchinblock-3].data+*dipblockoffset2);
		*currentdatablockno=*tempptr2;
		*currentdatablockoffset=0;
		return (*indirectiontype);
	}
	else if(*indirectiontype==2 && (*dipblockoffset2+sizeof(int))<block_size)
	{
		*dipblockoffset2+=sizeof(int);
		int dipblockno=file.b_inode.iNode[inodeno].dip;
		int* tempptr=(int*)((char*)file.b[dipblockno-3].data+*dipblockoffset1);
		int actualsearchinblock=*tempptr;
		int* tempptr2=(int*)((char*)file.b[actualsearchinblock-3].data+*dipblockoffset2);
		*currentdatablockno=*tempptr2;
		*currentdatablockoffset=0;
		return (*indirectiontype);
	}
	else if(*indirectiontype==2 && (*dipblockoffset2+sizeof(int))>=block_size && (*dipblockoffset1+sizeof(int))<block_size)
	{
		*dipblockoffset1+=sizeof(int);
		*dipblockoffset2=0;
		int dipblockno=file.b_inode.iNode[inodeno].dip;
		int* tempptr=(int*)((char*)file.b[dipblockno-3].data+*dipblockoffset1);
		int actualsearchinblock=*tempptr;
		int* tempptr2=(int*)((char*)file.b[actualsearchinblock-3].data+*dipblockoffset2);
		*currentdatablockno=*tempptr2;
		*currentdatablockoffset=0;
		return (*indirectiontype);
	}
	else
	{
		cout<<"The file system is full"<<endl;
		return -2;
	}


}

/////////////////////////////////////////////////////////////////////////////////////////
int my_mkdir(char *str)
{
	int notfound=0;
	int found=0;
	int toaddindirtype=0;
	int emptyposblock=-1;
	int emptyposoffset=-1;
	//search if same named file exists, if yes return -1
	//if no, 'add' an entry to the current directory blocks data
	//find an empty inode
	//in the empty inode, add the file name. Find an empty block and set that as startin block. Put . and .. info.
	//return 1
}

/////////////////////////////////////////////////////////////////////////////////////////
int my_rmdir(char *str)
{
	//search if same named file exists, if no return -1
	//go thru all the files associated with this and dealocate said files' blocks and inodes
	//remove this folder entry from current directory
	
}

////////////////////////////////////////////////////////////////////////////////////////
int my_chdir(char *str)
{
	//search if same named file exists, if no return -1
	//update current and prev directory.
}

/////////////////////////////////////////////////////////////////////////////////////////
int my_open(char *str)
{
	//search if same named file exists, if no return -1
	//if that file is a dir, return -2
	//else 'make' a new FD table entry and return its index
}

/////////////////////////////////////////////////////////////////////////////////////////
int my_read(int fd, char* buf, int count)
{
	//if fd is not valid then return -1
	//else read till count or eof
}

////////////////////////////////////////////////////////////////////////////////////////
int my_write(int fd, char *buf, size_t count)
{
	//if fd is not valid then return -1
	//else write till count
}

/////////////////////////////////////////////////////////////////////////////////////////
int my_close(int fd)
{
	//if fd is not valid then return -1
	//else drop the entry
}
